A WebExtensions version based on https://addons.mozilla.org/en-US/firefox/addon/card-color-titles-for-trello/
